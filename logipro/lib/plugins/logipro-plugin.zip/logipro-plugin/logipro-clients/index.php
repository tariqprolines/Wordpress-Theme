<?php 
/*
Plugin Name: Logopro Clients
Plugin URI: https://wwww.exhorn.com/
Description: This plugin show clients
Version: 1.0.0
Author:Mohd Tariq Khan
Author URI: https://WWW.logipro.com
Text Domain: logipro
*/

add_action('init', 'custom_post_client');

function custom_post_client(){
	$labels = array(
		'name' 				=> _x('Clients', 'Post Type General Name', 'logipro'),
		'singular_name' 	=> _x('Client', 'Post Type Singular Name' ,'logipro'),
		'add_new'			=> __('New Client', 'logipro'),
		'add_new_item'		=> __('Add New Client', 'logipro'),
		'edit_item'			=> __('Edit Client', 'logipro'),
		'view_item'			=> __('View Client', 'logipro'),
		'search_item'		=> __('Search Client', 'logipro'),
		'not_found'			=> __('No Client Found', 'logipro'),
		'not_found_in_trash'=> __('No Client Found in Trash', 'logipro'),
	);
	$args =array(
		'labels' 		=> $labels,
		'has_archive' 	=> true,
		'public'	 	=> true,
		'hierarchical'  => true,
		'supports' =>array(
			'title',
			'editor',
			'custom_fields',
			'excerpt',
			'thumbnail',
			'page_attributes'
		),
		'rewrite' => array('slug', 'clients'),
		'show_in_rest' =>true,
		'menu_icon' => 'dashicons-groups',
	);
	register_post_type('client',$args);
}

// Create Texonomy

function client_register_taxonomy() {    
      
    // books
    $labels = array(
        'name' => __( 'Categories' , 'logipro' ),
        'singular_name' => __( 'Category', 'logipro' ),
        'search_items' => __( 'Search Categories' , 'logipro' ),
        'all_items' => __( 'All Categories' , 'logipro' ),
        'edit_item' => __( 'Edit Category' , 'logipro' ),
        'update_item' => __( 'Update Categories' , 'logipro' ),
        'add_new_item' => __( 'Add New Category' , 'logipro' ),
        'new_item_name' => __( 'New Category' , 'logipro' ),
        'menu_name' => __( 'Categories' , 'logipro' ),
    );
      
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'sort' => true,
        'args' => array( 'orderby' => 'term_order' ),
        'rewrite' => array( 'slug' => 'client_categories' ),
        'show_admin_column' => true,
        'show_in_rest' => true
  
    );
      
    register_taxonomy( 'client_categories', array( 'client' ), $args);
      
}
add_action( 'init', 'client_register_taxonomy' );
?>