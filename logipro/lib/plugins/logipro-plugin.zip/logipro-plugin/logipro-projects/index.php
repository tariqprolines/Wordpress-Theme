<?php 
/*
Plugin Name: Logopro Projects
Plugin URI: https://wwww.exhorn.com/
Description: This plugin show projects
Version: 1.0.0
Author:Mohd Tariq Khan
Author URI: https://WWW.logipro.com
Text Domain: logipro
*/

add_action('init', 'logipro_project');

function logipro_project(){
	$labels = array(
		'name' 				=> _x('Projects', 'Post Type General Name', 'logipro'),
		'singular_name' 	=> _x('Project', 'Post Type Singular Name' ,'logipro'),
		'add_new'			=> __('New Project', 'logipro'),
		'add_new_item'		=> __('Add New Project', 'logipro'),
		'edit_item'			=> __('Edit Project', 'logipro'),
		'view_item'			=> __('View Project', 'logipro'),
		'search_item'		=> __('Search Project', 'logipro'),
		'not_found'			=> __('No Project Found', 'logipro'),
		'not_found_in_trash'=> __('No Project Found in Trash', 'logipro'),
	);
	$args =array(
		'labels' 		=> $labels,
		'has_archive' 	=> true,
		'public'	 	=> true,
		'hierarchical'  => true,
		'supports' =>array(
			'title',
			'editor',
			'custom_fields',
			'excerpt',
			'thumbnail',
			'page_attributes'
		),
		'rewrite' => array(
			'slug' => 'project'
		),
		'show_in_rest' =>true,
		'menu_icon' => 'dashicons-list-view',
	);
	register_post_type('project',$args);
}

// Create Texonomy

function project_register_taxonomy() {    
      
    // Projects
    $labels = array(
        'name' => __( 'Project Categories' , 'logipro' ),
        'singular_name' => __( 'Project Category', 'logipro' ),
        'search_items' => __( 'Search Project Categories' , 'logipro' ),
        'all_items' => __( 'All Project Categories' , 'logipro' ),
        'edit_item' => __( 'Edit Project Category' , 'logipro' ),
        'update_item' => __( 'Update Project Categories' , 'logipro' ),
        'add_new_item' => __( 'Add New Project Category' , 'logipro' ),
        'new_item_name' => __( 'New Project Category' , 'logipro' ),
        'menu_name' => __( 'Project Categories' , 'logipro' ),
    );
      
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'sort' => true,
        'args' => array( 'orderby' => 'term_order' ),
        'rewrite' => array( 'slug' => 'project_category' ),
        'show_admin_column' => true,
        'show_in_rest' => true,  
		'supports' => array('title','thumbnail'),
    );
      
    register_taxonomy( 'project_categories', array( 'project' ), $args);
      
}
add_action( 'init', 'project_register_taxonomy' );
?>